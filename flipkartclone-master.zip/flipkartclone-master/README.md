Flipkart clone is copy of Flipkart website and it's Static with features like add product to cart, remove from cart, increase quantity in cart, search product etc.
Technology used - : HTML 5, CSS 3, Javascript.

Link - : https://aadishjain1946.github.io/flipkartclone/
